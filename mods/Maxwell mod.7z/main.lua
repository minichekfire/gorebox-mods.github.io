local M = {}
local kd = time.getTime()
local jump = false
local rb = {}
local menuActive = false
local catActive = false
local cat = {}




function M.update()

        if input.getKeyDown("M") then
            log("m")
            menuActive = not menuActive
        end
            
    kdjump()




end


function M.guiUpdate()

    if menuActive == true then
        gui.beginArea(10, 220, 200, 200)

        gui.label("<align=center><color=green><size=20>Mod by: Easy Mods")

        gui.space(10)
        if gui.button("Spawn Maxwell") then
            AddMaxwell()
        end
        gui.space(10)
        gui.label("max 1")
        gui.space(10)

        if gui.button("Destroy Maxwell") then
            destroycat()
        end

        gui.endArea()
    end



end

function destroycat()
    if catActive == true then
    catActive = false
    gameObject.destroy(cat)
    end
end





function kdjump()

        if jump == true and time.getTime() >= kd then
            kd = time.getTime() + 1.5
            log("kd")
            local yr = math.randomFloat(3.5, 5)
            local xzr = math.randomFloat(-1, 1)
            rigidbody.setVelocity(rb, xzr, yr, xzr)
        end
end



function AddMaxwell()

    if catActive == false then
        catActive = true

    local playerID = getLocalPlayer()
    local playerTransform = gameObject.getTransform(playerID)
    local x, y, z = transform.getPosition(playerTransform)
    

    log("PlayerPos <br>x:".. x .. " | " .. "y:" .. y .. " | " .. "z:" .. z)
    cat = gameObject.createWithModel("MyObject", "models/maxwellModel.obj", "images/tex.jpg")
    rb = component.add(cat, "Rigidbody")
    component.add(cat, "BoxCollider")

    local t = gameObject.getTransform(cat)
    transform.setScale(t, 0.07,0.07,0.07)
    transform.setPosition(t,  x, y, z)


    clip = audioClip.load("audio/music.mp3")
    local audioId = audioSource.add(cat)
    audioSource.setClip(audioId, clip)
    audioSource.setVolume(audioId, 1)
    audioSource.setSpatial(audioId, 1.0)
    audioSource.play(audioId)
    audioSource.setLoop(audioId, true)

    jump = true
    kd = time.getTime() + 1.5
    kdjump()
    end

end




return M